<template>
  <li>{{ xyz }}</li>
</template>

<script>
export default {
  props: ["xyz"],
};
</script>

<style>
ol li {
  background-color: rgb(203, 214, 224);
  padding: 5px;
  margin-top: 5px;
  cursor: pointer;
}
ol li:hover {
  background-color: #abc;
}
</style>