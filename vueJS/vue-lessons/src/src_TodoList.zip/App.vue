<script>
import todoInput from "./todoinput.vue";
import todoItem from "./todoitem.vue";

export default {
  components: {
    todoInput,
    todoItem,
  },
  data() {
    return {
      tasks: [],
    };
  },
  methods: {
    addTask(item) {
      this.tasks.push(item);
    },
    removeTask(index) {
      this.tasks.splice(index, 1);
    },
  },
};
</script>
<template>
  <div>
    <todo-input @abc="addTask"></todo-input>
    <ol>
      <!-- <todo-item v-for="task in tasks" v-bind:xyz="task"></todo-item> -->
      <todo-item
        v-for="(task, index) in tasks"
        v-bind:xyz="task"
        @click.native="removeTask(index)"
      ></todo-item>
    </ol>
  </div>
</template>


