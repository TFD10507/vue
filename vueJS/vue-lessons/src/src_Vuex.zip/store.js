// 1. 修改main.js
// import Vue from 'vue'
// import Vuex from 'vuex'
// Vue.use(Vuex);

// const store = new Vuex.Store({ //global store
//     state:{ //類似 data, 存放變數
//         count: 0,
//         x:true,
//         y:new Date(),
//         z:'ABC',
//     },
//     mutations: { //類似 methods, 存放函數
//         addStoreCount(state){ //預設帶參數
//             state.count += 1;
//         },
//     },
// });

// export default store;


// 2. 不修改main.js
import Vue from 'vue'
import Vuex, {Store} from 'vuex' // 這行有修改
Vue.use(Vuex);

const store = new Store({  // 這行有修改
    state:{ 
        count: 0,
        x:true,
        y:new Date(),
        z:'ABC',
    },
    mutations: { //類似 methods, 存放函數
        addStoreCount(state){ //預設帶參數
            state.count += 1;
        },
    },
});

export default store;