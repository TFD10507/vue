<template>
  <div>
    <button @click="addCount">Add</button>
    <h2>{{ count }}</h2>
  </div>
</template>

<script>
// 1. 修改main.js
// export default {
//   methods: {
//     addCount() {
//       this.$store.commit("addStoreCount");
//     },
//   },
//   computed: {
//     count() {
//       return this.$store.state.count;
//     },
//   },
// };


// 2. 不修改main.js
import store from './store'
export default {
  methods: {
    addCount() {
      store.commit("addStoreCount");
    },
  },
  computed: {
    count() {
      return store.state.count;
    },
  },
};



</script>
