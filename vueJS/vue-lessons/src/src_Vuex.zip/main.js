import Vue from 'vue'
import App from './App.vue'

// import store from './store' //加這行


new Vue({
  el: '#app',

  // store, //加這行

  render: h => h(App)
})
