<template>
    <div>
        <h2>$Me</h2>
    </div>
</template>

<style scoped>
h2{
    font: 30px calibri;
    color: lightcoral;
}
</style>