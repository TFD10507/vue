<template>
    <div>
        <h2>@Home</h2>
    </div>
</template>

<style scoped>
h2{
    font: 30px calibri;
    color: lightblue;
}
</style>